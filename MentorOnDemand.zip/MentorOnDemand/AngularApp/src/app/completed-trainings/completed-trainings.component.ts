import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../training.service';
import { CompletedTraining } from '../Model/CompletedTraining';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-completed-trainings',
  templateUrl: './completed-trainings.component.html',
  styleUrls: ['./completed-trainings.component.css']
})
export class CompletedTrainingsComponent implements OnInit {
comp:CompletedTraining;
  completed : CompletedTraining[];
  constructor(private route: ActivatedRoute, private router: Router, private trainingService : TrainingService) { 

this.comp = new CompletedTraining;

  }


  onSubmit() {
    this.trainingService.saveCom(this.comp).subscribe(result => this.gotoTraList());
  }
 
  gotoTraList() {
    this.router.navigate(['/completedTraining']);
  }


  ngOnInit() {
    this.trainingService.findAllCom().subscribe(data=>{
      this.completed = data;
      console.log(this.comp);
    }
      
      )
  }
}
