import { Injectable } from '@angular/core';
import {HttpClientModule, HttpClient} from '@angular/common/http' 
import { Observable } from 'rxjs';
import { User } from './Model/User';


@Injectable({
  providedIn: 'root'
})
export class UserSService {

  
 
  constructor(private http: HttpClient) {
     }
 
private _url: string = "http://localhost:8081/"
private _url1 : string = "http://localhost:8087/user/users"
private _url2 : string = "http://localhost:8087/user"

  public findAll(): Observable<User[]> {
    return this.http.get<User[]>(this._url,{});
  }
 
  public save(user: User) {
    return this.http.post<User>(this._url1, user);
  }


  public deleteUser(user: User) {
    return this.http.delete(this._url2 + "/"+ user.uId);
  }


 



}
