import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LogInSignUpService } from '../log-in-sign-up.service';
import { CurrentUser } from '../Model/CurrentUser';
import { User } from '../Model/User';
import { UserSService } from '../user-s.service';

@Component({
  selector: 'app-user-landing',
  templateUrl: './user-landing.component.html',
  styleUrls: ['./user-landing.component.css']
})
export class UserLandingComponent implements OnInit {

    
  users : User[];    
 
  constructor(private http: HttpClient, private logInSignUp : LogInSignUpService) { }
public user: CurrentUser;


  ngOnInit() {

this.logInSignUp.currentUser.subscribe(data=>
  this.user=data
  );


  this.logInSignUp.findU(this.user.username).subscribe(data=>{

    this.users = data;
 
  })



 }

}
