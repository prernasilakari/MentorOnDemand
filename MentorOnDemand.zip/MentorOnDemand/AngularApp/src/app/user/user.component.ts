import { Component, OnInit } from '@angular/core';
import { LogInSignUpService } from '../log-in-sign-up.service';
import { CurrentUser } from '../Model/CurrentUser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private router: Router, private _loginSignUpService : LogInSignUpService) { }

  ngOnInit() {
  }

  public currentUser: CurrentUser;
  onLogInUser(formObj) {
    var usrObjTem = {
      "username": formObj.uname,
      "password": formObj.psw
    }
    this._loginSignUpService.getAuth(usrObjTem).subscribe(data => {
      this.currentUser = data;
      this._loginSignUpService.changeData(this.currentUser);
      console.log(this.currentUser);
    });

if(this.currentUser.username!= "")
this.router.navigate(['userLanding'])
else
this.router.navigate(['user'])

  }




}
