import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  constructor(private route: Router, private http: HttpClient) { }

  ngOnInit() {
  }



  
  onSignUp(formObject) {
    var userObj = {
      "id":4,
      "username": formObject.username,
      "password":formObject.password,
      "roleId":2
    }




    var userObj1 = {
     // "mentorId":formObject.mentorId,
     "mentorId":3,
      "mentorName": formObject.mentorName,
      "mSkills":formObject.mSkills
    }
this.route.navigate(['mentorLanding'])

    console.log(userObj);
  
     this.http.post("http://localhost:8080/register", userObj).subscribe();
     this.http.post("http://localhost:8082/mentors", userObj1).subscribe();
     
  }
}
