import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CurrentTraining } from './Model/CurrentTraining';
import { CompletedTraining } from './Model/CompletedTraining';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  constructor(private http: HttpClient) { }


  private _url : string = "http://localhost:8084/getCurrentTraining";

  private _url1 : string = "http://localhost:8084/currentTraining";
  private _url2 : string = "http://localhost:8084/getCompletedTraining";

  private _url3 : string = "http://localhost:8084/completedTraining";



  public findAll() : Observable<CurrentTraining[]>{

    return this.http.get<CurrentTraining[]>(this._url,{});
  }

  public save(currentTraining : CurrentTraining){

    return this.http.post<CurrentTraining>(this._url1, currentTraining);
  }


  
  public findAllCom() : Observable<CompletedTraining[]>{

    return this.http.get<CompletedTraining[]>(this._url2,{});
  }

  public saveCom(completedTraining : CompletedTraining){

    return this.http.post<CompletedTraining>(this._url3, completedTraining);
  }


}
