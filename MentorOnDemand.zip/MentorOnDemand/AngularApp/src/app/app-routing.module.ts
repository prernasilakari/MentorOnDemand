import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { PaymentComponent } from './payment/payment.component';
import { ProfileComponent } from './profile/profile.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';
import { ChangeFeesComponent } from './change-fees/change-fees.component';
import { BlockUserComponent } from './block-user/block-user.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { HeaderComponent } from './header/header.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserFormComponent } from './user-form/user-form.component';
import { MentorListComponent } from './mentor-list/mentor-list.component';
import { MentorFormComponent } from './mentor-form/mentor-form.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGaurdService } from './auth-guard.service';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';



const routes: Routes = [
  { path: '', component: HeaderComponent },
  { path: 'userList', component: UserListComponent },
  { path: 'mentorLogin', component: MentorLoginComponent },
  { path: 'logout', component: LogoutComponent, canActivate:[AuthGaurdService]},
  { path: 'mentorList', component: MentorListComponent },
  { path: 'addmentor', component: MentorFormComponent },
{ path: 'search', component: SearchComponent },
{ path: 'admin', component: AdminComponent },
{ path: 'user', component: UserComponent},
{ path: 'adduser', component: UserFormComponent },
{ path: 'adminLanding', component: AdminLandingComponent},
{ path: 'userLanding', component: UserLandingComponent},
{ path: 'currentTraining', component: CurrentTrainingComponent},
{ path: 'completedTrainings', component: CompletedTrainingsComponent},
{ path: 'editSkills', component: EditSkillsComponent},
{ path: 'payment', component: PaymentComponent},
{ path: 'profile', component: ProfileComponent},
{ path: 'userSignup', component: UserSignupComponent},
{ path: 'mentorLanding', component: MentorLandingComponent},
{ path: 'blockUser', component: BlockUserComponent},
{ path: 'changeFees', component: ChangeFeesComponent},
{ path: 'mentorSignup', component: MentorSignupComponent},
{ path: 'UserSignUp', component: UserSignupComponent},
{ path: 'Header', component: HeaderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponent = [SearchComponent,AdminComponent,
  UserComponent, AdminLandingComponent,
  UserLandingComponent,
  MentorLandingComponent,
  CurrentTrainingComponent,
  MentorSignupComponent,
  EditSkillsComponent,
  PaymentComponent,
  ProfileComponent,
  UserSignupComponent,
  UserListComponent,
  UserFormComponent,
  MentorListComponent,
  MentorFormComponent,
CompletedTrainingsComponent,
BlockUserComponent,
ChangeFeesComponent, 
HeaderComponent,
LogoutComponent,
MentorLoginComponent]