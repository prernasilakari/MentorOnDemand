import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../data.service';
import { UserSService } from '../user-s.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {

  message:string;
  
  constructor(private route: Router, private http: HttpClient, private data: DataService) { }

  
 
  onSignUp(formObject) {
    var userObj = {
      "id":2,
      "username": formObject.username,
      "password":formObject.password,
      "roleId":1
    }

 formObject.username = this.message;

    var userObj1 = {
      "uId":formObject.uid,
      "userName": formObject.username,
      "firstName":formObject.firstname,
      "lastName": formObject.lastname
    }
this.route.navigate(['userLanding'])

    console.log(userObj);
  
     this.http.post("http://localhost:8080/register", userObj).subscribe();
     this.http.post("http://localhost:8081/users", userObj1).subscribe();
     
  }

  ngOnInit() {
    // this.data.currentMessage.subscribe(message =>  formObject.username = this.message;)
  }
  

  

}
