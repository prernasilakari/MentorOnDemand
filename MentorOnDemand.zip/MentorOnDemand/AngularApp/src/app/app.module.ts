import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule, routingComponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { PaymentComponent } from './payment/payment.component';
import { ProfileComponent } from './profile/profile.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';
import { BlockUserComponent } from './block-user/block-user.component';
import { ChangeFeesComponent } from './change-fees/change-fees.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { HeaderComponent } from './header/header.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserFormComponent } from './user-form/user-form.component';
import { UserSService } from './user-s.service';
import { HttpClientModule } from '@angular/common/http';
import { MentorListComponent } from './mentor-list/mentor-list.component';
import { MentorFormComponent } from './mentor-form/mentor-form.component';
import { LogoutComponent } from './logout/logout.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';


@NgModule({
  declarations: [
    AppComponent,
    routingComponent,
    AdminLandingComponent,
    UserLandingComponent,
    MentorLandingComponent,
    CurrentTrainingComponent,
    UserListComponent,
    EditSkillsComponent,
    PaymentComponent,
    UserFormComponent,
    ProfileComponent,
    UserSignupComponent,
    CompletedTrainingsComponent,
    BlockUserComponent,
    ChangeFeesComponent,
    MentorSignupComponent,
    HeaderComponent,
    UserListComponent,
    MentorListComponent,
    MentorFormComponent,
    LogoutComponent,
    MentorLoginComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
 
  ],
  providers: [UserSService],
  bootstrap: [AppComponent]
})
export class AppModule { }
