import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { UserSService } from '../user-s.service';
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users : User[];
  constructor(private userService : UserSService) { }

  ngOnInit() {
    this.userService.findAll().subscribe(data=>{

      this.users = data;
    })

  }



  deleteUser(user: User): void {
    this.userService.deleteUser(user)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

}
