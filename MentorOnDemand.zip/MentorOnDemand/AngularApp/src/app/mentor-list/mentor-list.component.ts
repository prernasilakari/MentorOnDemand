import { Component, OnInit } from '@angular/core';
import { Mentor } from '../Model/Mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-list',
  templateUrl: './mentor-list.component.html',
  styleUrls: ['./mentor-list.component.css']
})
export class MentorListComponent implements OnInit {

mentor : Mentor[];

  constructor(private mentorService : MentorService) { }

  ngOnInit() {

    this.mentorService.findAll().subscribe(data=>
    {
this.mentor = data;

    })
  }


  
  deleteMentor(mentor: Mentor): void {
    this.mentorService.deleteMentor(mentor)
      .subscribe( data => {
        this.mentor = this.mentor.filter(u => u !== mentor);
      })
  };

}
