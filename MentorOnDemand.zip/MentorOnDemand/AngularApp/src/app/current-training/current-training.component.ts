import { Component, OnInit } from '@angular/core';
import { CurrentTraining } from '../Model/CurrentTraining';
import { TrainingService } from '../training.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {
  curr : CurrentTraining;
  current : CurrentTraining[];

  constructor(private router : Router,private trainingService : TrainingService, route : ActivatedRoute) {
    this.curr = new CurrentTraining;
   }


   onSubmit() {
    this.trainingService.save(this.curr).subscribe(result => this.gotoTList());
    console.log(this.curr)

  }
 
  gotoTList() {
    this.router.navigate(['/currentTraining']);
  }

  ngOnInit() {
    this.trainingService.findAll().subscribe(data=>{
      this.current = data;
      console.log(data)
    }
      
      )
  }

 



}
