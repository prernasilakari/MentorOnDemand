import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClientModule, HttpClient} from '@angular/common/http' 
import { Mentor } from './Model/Mentor';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor(private http: HttpClient) { }
   private _url: string = "http://localhost:8082/"
  //private _url: string = "http://localhost:8082/m/ds"
  private _url1 : string = "http://localhost:8087/mentor/mentors"
  private _url2 : string = "http://localhost:8087/mentor"
    //new remove if error
    public findAll(): Observable<Mentor[]> {
      return this.http.get<Mentor[]>(this._url,{});this.http.get<Mentor[]>(this._url,{});
    }
    public save(mentor: Mentor) {
      return this.http.post<Mentor>(this._url1, mentor);
    }
    public deleteMentor(mentor: Mentor) {
      return this.http.delete(this._url2 + "/"+ mentor.mentorId);
    }
  

}
