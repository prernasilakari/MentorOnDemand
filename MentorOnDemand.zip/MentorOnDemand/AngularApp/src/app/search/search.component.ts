import { Component, OnInit } from '@angular/core';
import { Mentor } from '../Model/Mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  mentor : Mentor[];

  constructor(private mentorService : MentorService) { }

  ngOnInit() {

    this.mentorService.findAll().subscribe(data=>
    {
this.mentor = data;

    })
  }


  
  deleteMentor(mentor: Mentor): void {
    this.mentorService.deleteMentor(mentor)
      .subscribe( data => {
        this.mentor = this.mentor.filter(u => u !== mentor);
      })
  };

}
