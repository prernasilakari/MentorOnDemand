import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CurrentUser } from './Model/CurrentUser';
import { Observable, BehaviorSubject } from 'rxjs';
import { User } from './Model/User';

@Injectable({
  providedIn: 'root'
})
export class LogInSignUpService {

  constructor(private http: HttpClient) { }

  currentUserTemp: CurrentUser;
  private dataSource = new BehaviorSubject(this.currentUserTemp);
  currentUser = this.dataSource.asObservable();

  changeData(currentUser: CurrentUser) {
    this.dataSource.next(currentUser);
  }
  
  getAuth(formObj): Observable<CurrentUser> {
    return this.http.post<CurrentUser>("http://localhost:8080/login", formObj);
  }
  private _url: string = "http://localhost:8081/u"


  public findU(username: string): Observable<User[]> {
    return this.http.get<User[]>(this._url +"/"+ username);

    
  }
}
