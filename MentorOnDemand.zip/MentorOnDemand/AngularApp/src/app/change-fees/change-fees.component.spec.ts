import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeFeesComponent } from './change-fees.component';

describe('ChangeFeesComponent', () => {
  let component: ChangeFeesComponent;
  let fixture: ComponentFixture<ChangeFeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeFeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeFeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
