import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-fees',
  templateUrl: './change-fees.component.html',
  styleUrls: ['./change-fees.component.css']
})
export class ChangeFeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
