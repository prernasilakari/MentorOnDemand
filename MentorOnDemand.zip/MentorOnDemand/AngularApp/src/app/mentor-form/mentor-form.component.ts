import { Component, OnInit } from '@angular/core';
import { Mentor } from '../Model/Mentor';
import { ActivatedRoute, Router } from '@angular/router';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-form',
  templateUrl: './mentor-form.component.html',
  styleUrls: ['./mentor-form.component.css']
})
export class MentorFormComponent implements OnInit {

  mentor: Mentor;
  constructor(private route : ActivatedRoute, private router : Router, private mentorService: MentorService) {
    this.mentor = new Mentor();
   }

onSubmit(){

  this.mentorService.save(this.mentor).subscribe(result=>this.gotoMentorList());
}

gotoMentorList(){

this.router.navigate(['/mentorList']);

}
  ngOnInit() {
  }

}
