export class CompletedTraining
{
 compId : number;
  userDtls : number; 
 mentorDtls: number;
 trainingName : string;
progress : number;
}