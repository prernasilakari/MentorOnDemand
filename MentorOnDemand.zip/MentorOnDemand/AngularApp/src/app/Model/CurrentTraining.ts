export class CurrentTraining
{
 compId : number;

 trainingName : string;
progress : number;
}