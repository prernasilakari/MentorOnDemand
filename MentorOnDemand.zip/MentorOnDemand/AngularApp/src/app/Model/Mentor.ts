export class Mentor{

mentorId : number;
mentorName : string;
mSkills : string;
}