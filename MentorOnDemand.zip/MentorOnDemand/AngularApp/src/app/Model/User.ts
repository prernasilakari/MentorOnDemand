export class User {
    uId: number;
    userName: string;
    firstName: string;
    lastName: string
}