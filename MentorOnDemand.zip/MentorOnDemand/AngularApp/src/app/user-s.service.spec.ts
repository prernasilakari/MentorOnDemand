import { TestBed } from '@angular/core/testing';

import { UserSService } from './user-s.service';

describe('UserSService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserSService = TestBed.get(UserSService);
    expect(service).toBeTruthy();
  });
});
