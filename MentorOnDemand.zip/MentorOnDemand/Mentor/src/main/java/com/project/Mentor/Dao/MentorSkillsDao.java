package com.project.Mentor.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Mentor.Model.MentorSkills;

public interface MentorSkillsDao extends JpaRepository<MentorSkills, Long>{

}
