package com.project.Mentor.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Mentor.Model.MentorCalender;

public interface MentorCalenderDao extends JpaRepository<MentorCalender, Long> {

}
