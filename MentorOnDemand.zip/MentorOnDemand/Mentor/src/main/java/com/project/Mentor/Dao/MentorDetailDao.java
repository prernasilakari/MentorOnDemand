package com.project.Mentor.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Mentor.Model.MentorDetail;

public interface MentorDetailDao extends JpaRepository<MentorDetail, Long> {
	MentorDetail findByMentorName(String name);
}
