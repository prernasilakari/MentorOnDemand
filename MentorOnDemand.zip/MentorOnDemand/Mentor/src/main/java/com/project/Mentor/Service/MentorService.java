package com.project.Mentor.Service;

import java.util.List;
import java.util.Optional;

import com.project.Mentor.Model.MentorDetail;

public interface MentorService {

    void create(MentorDetail mentor);
    
    void update(MentorDetail mentor);
    
    void delete(long id);
    
    List<MentorDetail> getAll();

Optional<MentorDetail> findById(long id);
	
	MentorDetail findByMentorName(String name);
}
