package com.project.MyApiGateway.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.MyApiGateway.model.Role;
public interface RoleDao extends JpaRepository<Role, Long> {

}
