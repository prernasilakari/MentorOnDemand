package com.project.MyApiGateway.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.MyApiGateway.model.User;

public interface UserDao extends JpaRepository<com.project.MyApiGateway.model.User, Long> {
	public User findByUsername(String username);
}
