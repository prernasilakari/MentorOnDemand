package com.project.MyApiGateway.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.MyApiGateway.Dto.UserObjDto;
import com.project.MyApiGateway.Impl.UserDetailServiceImplementation;
import com.project.MyApiGateway.model.SaveUserDto;
import com.project.MyApiGateway.model.UserDto;

@CrossOrigin("*")
@RestController
public class SampleController {

	@Autowired
	com.project.MyApiGateway.Dao.UserDao userDao;
	
	@Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private AuthenticationManager authenticationManager;
   
   
    @PostMapping("/login")
    public UserObjDto login(@RequestBody UserDto loginUser) {
//    	final Authentication authentication = authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(
//                        loginUser.getUsername(),
//                        loginUser.getPassword()
//                )
//               );
//    	SecurityContextHolder.getContext().setAuthentication(authentication);
//    	System.out.println("My auth " + SecurityContextHolder.getContext().getAuthentication());
    	
    	return new UserObjDto(userDao.findByUsername(loginUser.getUsername()).getId(), userDao.findByUsername(loginUser.getUsername()).getUsername(),userDao.findByUsername(loginUser.getUsername()).getRole().getRoleName());
    }
    
    @GetMapping("/get")
    public String get() {
    	return "Hello";
    }
    
    @GetMapping("/getUserObj/{username}")
    public UserObjDto getRole(@PathVariable String username) {
    	System.out.println(userDao.findByUsername(username));
    	return new UserObjDto(userDao.findByUsername(username).getId(), userDao.findByUsername(username).getUsername(), userDao.findByUsername(username).getRole().getRoleName());
    }
    
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public void register(@RequestBody SaveUserDto loginUser) {
    	((UserDetailServiceImplementation) userDetailsService).saveUser(loginUser);
    }
}
